#!/bin/bash

kill $(lsof -t -i:9918)