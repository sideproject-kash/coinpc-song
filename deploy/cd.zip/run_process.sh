#!/bin/bash
nohup java -jar coinpc-0.0.1-SNAPSHOT.jar > ./springboot.log 2>&1 &